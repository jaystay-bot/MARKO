# MARKO Lead Finder

Local business prospecting tool for MARKO outreach campaigns.
Finds, enriches, scores, and exports leads using official APIs only.

---

## What This Tool Does

1. **Search** — finds local businesses by keyword + location using Google Places API (New)
2. **Enrich** — visits each business's own public website, extracts contact info and site quality signals
3. **Deduplicate** — removes duplicate records using place_id, domain, phone, and name matching
4. **Score** — rates each lead 0–100 based on digital weakness and outreach opportunity
5. **Export** — outputs CSV, JSON, and a markdown summary report for MARKO

---

## Compliant Design

- Uses **Google Places API (New)** only — no scraping of Google Maps HTML
- Uses an honest, identifying User-Agent string — no spoofing
- Only visits **public business websites** — no login, no forms, no auth
- Only extracts **publicly displayed** contact information
- No CAPTCHA bypass, no browser automation on third-party sites
- No email guessing or personal data inference

---

## Setup

### 1. Clone and install

```bash
cd lead_finder
pip install -r requirements.txt
```

### 2. Configure environment

```bash
cp .env.example .env
```

Edit `.env` and add your Google Maps API key:

```
GOOGLE_MAPS_API_KEY=your_key_here
```

### 3. Enable Google Places API

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create or select a project
3. Navigate to **APIs & Services → Library**
4. Search for **Places API (New)** and enable it
5. Go to **APIs & Services → Credentials**
6. Create an **API Key**
7. Restrict the key to **Places API (New)** for security
8. Copy the key into your `.env` file

**Billing note:** The Places API has a free tier ($200/month credit). Field masks minimize cost — this tool only requests the fields it needs.

---

## Commands

### Search by keyword + location
```bash
python app.py search --query "roofers" --location "Richmond, VA" --limit 40
python app.py search --query "med spas" --location "Virginia Beach, VA" --limit 30
python app.py search --query "plumbers" --location "Norfolk, VA" --limit 60
python app.py search --query "vape shops" --location "Colonial Heights, VA" --limit 20
python app.py search --query "used car dealers" --location "Raleigh, NC" --limit 40
```

### Search by coordinates (nearby)
```bash
python app.py nearby --keyword "camera store" --lat 35.2271 --lng -80.8431 --radius 12000 --limit 30
python app.py nearby --keyword "med spa" --lat 36.8529 --lng -75.9780 --radius 10000 --limit 25
```

### Enrich websites
```bash
python app.py enrich --batch-size 20
```

### Score leads
```bash
python app.py score
```

### Export
```bash
python app.py export --format csv
python app.py export --format json
python app.py export --format all
```

### Full pipeline (one command)
```bash
python app.py run --query "plumbers" --location "Norfolk, VA" --limit 40
python app.py run --query "roofers" --location "Richmond, VA" --limit 60 --format all
```

### Database status report
```bash
python app.py report
```

---

## Run Tests

```bash
python tests/test_normalization.py
python tests/test_dedupe.py
python tests/test_contact_parser.py
python tests/test_score_service.py
```

---

## Expected Output

After a full run, the `exports/` folder will contain:

| File | Contents |
|------|----------|
| `leads_[timestamp].csv` | All scored, non-duplicate leads |
| `hot_leads_[timestamp].csv` | Leads scoring 80+ only |
| `outreach_ready_[timestamp].csv` | Leads with contact data + score ≥ 40 |
| `leads_[timestamp].json` | Full lead data in JSON |
| `summary_report_[timestamp].md` | Human-readable top opportunities |

### CSV columns
`business_name, category, address, city, state, phone, website_url, contact_email, contact_page_url, booking_page_url, lead_score, lead_tier, top_3_reasons, google_maps_url, source, notes`

---

## Lead Scoring

| Tier | Score | Meaning |
|------|-------|---------|
| 🔴 Hot | 80–100 | Strong digital weakness — high priority |
| 🟡 Warm | 60–79 | Notable gaps — good prospect |
| 🟢 Mild | 40–59 | Some opportunity |
| ⚪ Low | 0–39 | Established or low opportunity |

**What raises score:**
- No website (+20)
- Broken/parked website (+18)
- No booking flow (+15)
- No contact page (+12)
- No CTA (+10)
- Social-only presence (+8)
- Missing metadata (+4–8)
- No SSL (+4)
- Few reviews (+3–6)
- No public email (+5)

**What lowers score:**
- Large chain/franchise keywords (−15)
- Highly rated with many reviews (−10)
- Duplicate record (−8)

---

## How MARKO Should Use This Output

1. Run the full pipeline for your target niche + city
2. Open `outreach_ready_[timestamp].csv` in Google Sheets
3. Sort by `lead_score` descending
4. Start with **Hot** tier leads
5. Use `contact_email` for cold email outreach via Gmail + Gmass
6. Use `phone` for SMS or call outreach
7. Use `contact_page_url` if no email — fill out their contact form manually
8. Reference `top_3_reasons` to personalize your message:
   - No website → "I noticed you don't have a website yet..."
   - No booking flow → "I noticed you don't have online booking..."
   - Broken site → "I found your website seems to be down..."
9. Log results back to the campaign tracker in MARKO Command Center
10. Run a new search for the next city in the state rollout order

---

## Limitations

- Requires a Google Maps API key with Places API (New) enabled
- Google Places API has billing — free tier covers ~$200/month
- Website enrichment depends on public site availability
- Email extraction only finds publicly displayed emails — no guessing
- Some businesses list phone but no email — use contact page as fallback
- Rate limiting: tool respects API limits with retry/backoff

---

## File Structure

```
lead_finder/
├── app.py                    ← CLI entry point (all commands)
├── config.py                 ← Settings from .env
├── models.py                 ← SQLAlchemy ORM tables
├── database.py               ← DB init and sessions
├── schemas.py                ← Pydantic data schemas
├── utils.py                  ← Normalization helpers
├── logging_setup.py          ← Structured logging
├── clients/
│   ├── google_places.py      ← Google Places API (New) client
│   └── website_fetcher.py    ← Safe HTTP fetcher for business sites
├── services/
│   ├── search_service.py     ← Search orchestration + DB insert
│   ├── enrich_service.py     ← Website enrichment pipeline
│   ├── dedupe_service.py     ← Deduplication logic
│   ├── score_service.py      ← Lead scoring 0–100
│   └── export_service.py     ← CSV/JSON/markdown export
├── parsers/
│   └── contact_parser.py     ← HTML contact info + signal extraction
├── tests/
│   ├── test_normalization.py
│   ├── test_dedupe.py
│   ├── test_contact_parser.py
│   └── test_score_service.py
├── .env.example
├── requirements.txt
└── README.md
```

---

*MARKO Lead Finder v1.0 — Built for Jay's outreach operation*
*Part of the MARKO + POLO growth system*
