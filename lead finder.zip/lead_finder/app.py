"""
app.py
MARKO Lead Finder — CLI entry point.
Commands: search, nearby, enrich, score, export, run, report
"""
import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import print as rprint

app = typer.Typer(
    name="marko-leads",
    help="MARKO Lead Finder — local business prospecting for outreach campaigns.",
    add_completion=False,
)
console = Console()


def _check_api_key():
    from config import config
    if not config.GOOGLE_MAPS_API_KEY:
        rprint("[red]ERROR: GOOGLE_MAPS_API_KEY is not set in .env[/red]")
        rprint("Copy .env.example → .env and add your key.")
        raise typer.Exit(1)


@app.command()
def search(
    query: str = typer.Option(..., "--query", "-q", help="Business type, e.g. 'roofers'"),
    location: str = typer.Option(..., "--location", "-l", help="City + state, e.g. 'Richmond, VA'"),
    limit: int = typer.Option(20, "--limit", "-n", help="Max results (default 20)"),
):
    """Search for local businesses by keyword + location."""
    _check_api_key()
    from services.search_service import run_text_search

    console.print(Panel(
        f"[bold]Search:[/bold] {query} in {location}\n[bold]Limit:[/bold] {limit}",
        title="MARKO — Text Search",
        style="green",
    ))

    result = run_text_search(query, location, limit)

    table = Table(title="Search Results")
    table.add_column("Found", style="cyan")
    table.add_column("Inserted", style="green")
    table.add_column("Skipped (dup)", style="yellow")
    table.add_row(str(result["found"]), str(result["inserted"]), str(result["skipped"]))
    console.print(table)
    console.print(f"[green]✓ Done. Run 'enrich' next.[/green]")


@app.command()
def nearby(
    keyword: str = typer.Option(..., "--keyword", "-k", help="Business keyword, e.g. 'med spa'"),
    lat: float = typer.Option(..., "--lat", help="Latitude"),
    lng: float = typer.Option(..., "--lng", help="Longitude"),
    radius: int = typer.Option(10000, "--radius", "-r", help="Search radius in meters"),
    limit: int = typer.Option(20, "--limit", "-n", help="Max results"),
):
    """Search businesses near a lat/lng coordinate."""
    _check_api_key()
    from services.search_service import run_nearby_search

    console.print(Panel(
        f"[bold]Keyword:[/bold] {keyword}\n"
        f"[bold]Location:[/bold] ({lat}, {lng})\n"
        f"[bold]Radius:[/bold] {radius}m | [bold]Limit:[/bold] {limit}",
        title="MARKO — Nearby Search",
        style="green",
    ))

    result = run_nearby_search(keyword, lat, lng, radius, limit)

    table = Table(title="Nearby Search Results")
    table.add_column("Found", style="cyan")
    table.add_column("Inserted", style="green")
    table.add_column("Skipped (dup)", style="yellow")
    table.add_row(str(result["found"]), str(result["inserted"]), str(result["skipped"]))
    console.print(table)
    console.print(f"[green]✓ Done. Run 'enrich' next.[/green]")


@app.command()
def enrich(
    batch_size: int = typer.Option(20, "--batch-size", "-b", help="Leads to enrich per run"),
):
    """Visit business websites and extract contact info + site signals."""
    from services.enrich_service import run_enrichment
    from services.dedupe_service import run_dedupe

    console.print(Panel(
        f"[bold]Batch size:[/bold] {batch_size}",
        title="MARKO — Website Enrichment",
        style="blue",
    ))

    # Dedupe first
    console.print("[dim]Running deduplication...[/dim]")
    dedupe_result = run_dedupe()
    console.print(
        f"[dim]Dedupe: {dedupe_result['duplicates_marked']} duplicates marked[/dim]"
    )

    result = run_enrichment(batch_size)

    table = Table(title="Enrichment Results")
    table.add_column("Enriched", style="green")
    table.add_column("Failed/Dead", style="red")
    table.add_row(str(result["enriched"]), str(result["failed"]))
    console.print(table)
    console.print("[green]✓ Done. Run 'score' next.[/green]")


@app.command()
def score():
    """Score all enriched leads by outreach opportunity (0–100)."""
    from services.score_service import run_scoring

    console.print(Panel("Scoring all enriched leads...", title="MARKO — Lead Scoring", style="yellow"))
    result = run_scoring()
    console.print(f"[green]✓ Scored {result['scored']} leads.[/green]")
    console.print("[dim]Tiers: Hot(80+) Warm(60+) Mild(40+) Low(<40)[/dim]")
    console.print("Run 'export' next.")


@app.command()
def export(
    fmt: str = typer.Option("csv", "--format", "-f", help="Output format: csv, json, all"),
):
    """Export leads to CSV, JSON, and markdown summary."""
    from services.export_service import run_export

    console.print(Panel(
        f"[bold]Format:[/bold] {fmt}",
        title="MARKO — Export",
        style="magenta",
    ))

    result = run_export(fmt)

    if not result["files"]:
        console.print("[red]No scored leads found. Run 'score' first.[/red]")
        return

    table = Table(title="Export Summary")
    table.add_column("Metric", style="cyan")
    table.add_column("Count", style="green")
    table.add_row("Total leads", str(result["total"]))
    table.add_row("Hot leads", str(result["hot"]))
    table.add_row("Outreach-ready", str(result["outreach_ready"]))
    console.print(table)

    console.print("\n[bold]Files written:[/bold]")
    for f in result["files"]:
        console.print(f"  [green]→[/green] {f}")

    console.print(
        "\n[bold green]✓ MARKO: Load outreach_ready.csv into your campaign tracker.[/bold green]"
    )


@app.command()
def run(
    query: str = typer.Option(..., "--query", "-q", help="Business type"),
    location: str = typer.Option(..., "--location", "-l", help="City + state"),
    limit: int = typer.Option(20, "--limit", "-n", help="Max results"),
    batch_size: int = typer.Option(20, "--batch-size", "-b", help="Enrichment batch size"),
    fmt: str = typer.Option("csv", "--format", "-f", help="Export format"),
):
    """Full pipeline: search → enrich → score → export in one command."""
    _check_api_key()

    console.print(Panel(
        f"[bold]Query:[/bold] {query} in {location}\n"
        f"[bold]Limit:[/bold] {limit} | [bold]Format:[/bold] {fmt}",
        title="MARKO — Full Pipeline Run",
        style="bold green",
    ))

    from services.search_service import run_text_search
    from services.dedupe_service import run_dedupe
    from services.enrich_service import run_enrichment
    from services.score_service import run_scoring
    from services.export_service import run_export

    console.print("\n[bold]Step 1/5:[/bold] Searching...")
    s = run_text_search(query, location, limit)
    console.print(f"  Found {s['found']} | Inserted {s['inserted']} | Skipped {s['skipped']}")

    console.print("\n[bold]Step 2/5:[/bold] Deduplicating...")
    d = run_dedupe()
    console.print(f"  Duplicates marked: {d['duplicates_marked']}")

    console.print("\n[bold]Step 3/5:[/bold] Enriching websites...")
    e = run_enrichment(batch_size)
    console.print(f"  Enriched: {e['enriched']} | Failed: {e['failed']}")

    console.print("\n[bold]Step 4/5:[/bold] Scoring leads...")
    sc = run_scoring()
    console.print(f"  Scored: {sc['scored']}")

    console.print("\n[bold]Step 5/5:[/bold] Exporting...")
    ex = run_export(fmt)
    console.print(f"  Total: {ex['total']} | Hot: {ex['hot']} | Outreach-ready: {ex['outreach_ready']}")

    console.print("\n[bold green]✓ Pipeline complete.[/bold green]")
    for f in ex.get("files", []):
        console.print(f"  [green]→[/green] {f}")


@app.command()
def report():
    """Show a quick stats summary of current leads in the database."""
    from database import get_session
    from models import Lead, OutreachSignal
    from sqlalchemy import func

    session = get_session()

    total = session.query(func.count(Lead.id)).scalar()
    enriched = session.query(func.count(Lead.id)).filter(Lead.enriched_at.isnot(None)).scalar()
    scored = session.query(func.count(Lead.id)).filter(Lead.lead_score.isnot(None)).scalar()
    dupes = session.query(func.count(Lead.id)).filter(Lead.is_duplicate == True).scalar()

    hot = session.query(func.count(Lead.id)).filter(Lead.lead_tier == "Hot").scalar()
    warm = session.query(func.count(Lead.id)).filter(Lead.lead_tier == "Warm").scalar()
    mild = session.query(func.count(Lead.id)).filter(Lead.lead_tier == "Mild").scalar()
    low = session.query(func.count(Lead.id)).filter(Lead.lead_tier == "Low").scalar()

    table = Table(title="MARKO Lead Database Status")
    table.add_column("Metric", style="cyan")
    table.add_column("Count", style="green", justify="right")
    table.add_row("Total leads", str(total))
    table.add_row("Enriched", str(enriched))
    table.add_row("Scored", str(scored))
    table.add_row("Duplicates", str(dupes))
    table.add_row("─────────", "───")
    table.add_row("🔴 Hot (80+)", str(hot))
    table.add_row("🟡 Warm (60+)", str(warm))
    table.add_row("🟢 Mild (40+)", str(mild))
    table.add_row("⚪ Low (<40)", str(low))

    console.print(table)
    session.close()


if __name__ == "__main__":
    app()
