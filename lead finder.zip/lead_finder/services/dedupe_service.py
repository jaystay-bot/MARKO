"""
services/dedupe_service.py
Deduplication of leads using place_id, domain, phone, name+city, address+name.
Safe dedup: merges non-conflicting fields, prefers richer records.
"""
import logging
from sqlalchemy.orm import Session
from models import Lead
from utils import normalize_name, normalize_domain, normalize_phone, normalize_address
from database import get_session

logger = logging.getLogger("marko.dedupe")


def _is_duplicate(lead: Lead, existing: Lead) -> bool:
    """Check if two leads are the same business."""
    # Same place_id
    if (lead.source_place_id and existing.source_place_id
            and lead.source_place_id == existing.source_place_id):
        return True

    # Same normalized domain
    if (lead.normalized_domain and existing.normalized_domain
            and lead.normalized_domain == existing.normalized_domain):
        return True

    # Same normalized name + same city
    if (lead.normalized_name and existing.normalized_name
            and lead.normalized_name == existing.normalized_name
            and lead.city and existing.city
            and lead.city.lower() == existing.city.lower()):
        return True

    # Same phone + same city
    lead_phone = normalize_phone(lead.phone or "")
    existing_phone = normalize_phone(existing.phone or "")
    if (lead_phone and existing_phone
            and lead_phone == existing_phone
            and lead.city and existing.city
            and lead.city.lower() == existing.city.lower()):
        return True

    # Same address + same normalized name
    lead_addr = normalize_address(lead.address or "")
    existing_addr = normalize_address(existing.address or "")
    if (lead_addr and existing_addr
            and lead_addr == existing_addr
            and lead.normalized_name == existing.normalized_name):
        return True

    return False


def _merge_into(keeper: Lead, dupe: Lead) -> None:
    """Merge non-conflicting fields from dupe into keeper. Keeper wins on conflict."""
    if not keeper.phone and dupe.phone:
        keeper.phone = dupe.phone
    if not keeper.website_url and dupe.website_url:
        keeper.website_url = dupe.website_url
        keeper.normalized_domain = dupe.normalized_domain
    if not keeper.rating and dupe.rating:
        keeper.rating = dupe.rating
        keeper.rating_count = dupe.rating_count
    if not keeper.google_maps_url and dupe.google_maps_url:
        keeper.google_maps_url = dupe.google_maps_url


def run_dedupe() -> dict:
    """
    Scan all leads and mark duplicates.
    Returns summary stats.
    """
    session: Session = get_session()

    all_leads = (
        session.query(Lead)
        .filter(Lead.is_duplicate == False)
        .order_by(Lead.id)
        .all()
    )

    logger.info(f"Deduplicating {len(all_leads)} leads...")
    marked = 0

    seen: list[Lead] = []

    for lead in all_leads:
        found_dupe = False
        for keeper in seen:
            if _is_duplicate(lead, keeper):
                logger.debug(
                    f"Duplicate: '{lead.business_name}' → keeper id={keeper.id}"
                )
                _merge_into(keeper, lead)
                lead.is_duplicate = True
                lead.notes = f"Duplicate of lead id={keeper.id}"
                marked += 1
                found_dupe = True
                break
        if not found_dupe:
            seen.append(lead)

    session.commit()
    session.close()

    logger.info(f"Dedupe complete — marked {marked} duplicates")
    return {"total": len(all_leads), "duplicates_marked": marked, "unique": len(seen)}
