"""
services/export_service.py
Exports lead data to CSV, JSON, and markdown summary.
Generates outreach-ready filtered exports for MARKO.
"""
import json
import logging
from pathlib import Path
from datetime import datetime
import pandas as pd
from sqlalchemy.orm import Session
from models import Lead, Contact, OutreachSignal
from database import get_session

logger = logging.getLogger("marko.export")

OUTPUT_DIR = Path("./exports")


def _build_export_rows(session: Session, tier_filter: str = None) -> list[dict]:
    """Build flat export rows from leads + contacts + signals."""
    query = (
        session.query(Lead)
        .filter(Lead.is_duplicate == False)
        .filter(Lead.lead_score.isnot(None))
    )
    if tier_filter:
        query = query.filter(Lead.lead_tier == tier_filter)

    leads = query.order_by(Lead.lead_score.desc()).all()

    rows = []
    for lead in leads:
        contact = (
            session.query(Contact).filter_by(lead_id=lead.id).first()
        )
        sig = (
            session.query(OutreachSignal).filter_by(lead_id=lead.id).first()
        )

        reasons = []
        if lead.opportunity_flags_json:
            try:
                reasons = json.loads(lead.opportunity_flags_json)
            except Exception:
                pass

        rows.append({
            "business_name": lead.business_name,
            "category": lead.primary_type or "",
            "address": lead.address or "",
            "city": lead.city or "",
            "state": lead.state or "",
            "phone": contact.phone or lead.phone or "" if contact else lead.phone or "",
            "website_url": lead.website_url or "",
            "contact_email": contact.email or "" if contact else "",
            "contact_page_url": contact.contact_page_url or "" if contact else "",
            "booking_page_url": contact.booking_page_url or "" if contact else "",
            "lead_score": lead.lead_score or 0,
            "lead_tier": lead.lead_tier or "Low",
            "top_3_reasons": " | ".join(reasons[:3]),
            "google_maps_url": lead.google_maps_url or "",
            "source": lead.source or "google_places",
            "notes": lead.notes or "",
        })

    return rows


def run_export(fmt: str = "csv") -> dict:
    """
    Export leads to file(s). fmt: 'csv', 'json', or 'all'.
    Returns summary dict with file paths.
    """
    OUTPUT_DIR.mkdir(exist_ok=True)
    session: Session = get_session()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    files_written = []

    all_rows = _build_export_rows(session)
    hot_rows = [r for r in all_rows if r["lead_tier"] == "Hot"]
    warm_rows = [r for r in all_rows if r["lead_tier"] in ("Hot", "Warm")]

    # Outreach-ready filter: has some contact data, real site issue
    outreach_rows = [
        r for r in all_rows
        if (r["contact_email"] or r["phone"] or r["contact_page_url"])
        and r["lead_score"] >= 40
    ]

    if not all_rows:
        logger.warning("No scored leads to export. Run 'score' first.")
        session.close()
        return {"files": [], "total": 0}

    if fmt in ("csv", "all"):
        # All leads
        path = OUTPUT_DIR / f"leads_{timestamp}.csv"
        pd.DataFrame(all_rows).to_csv(path, index=False)
        files_written.append(str(path))
        logger.info(f"Wrote {len(all_rows)} rows → {path}")

        # Hot leads
        if hot_rows:
            path = OUTPUT_DIR / f"hot_leads_{timestamp}.csv"
            pd.DataFrame(hot_rows).to_csv(path, index=False)
            files_written.append(str(path))
            logger.info(f"Wrote {len(hot_rows)} hot leads → {path}")

        # Outreach-ready
        if outreach_rows:
            path = OUTPUT_DIR / f"outreach_ready_{timestamp}.csv"
            pd.DataFrame(outreach_rows).to_csv(path, index=False)
            files_written.append(str(path))
            logger.info(f"Wrote {len(outreach_rows)} outreach-ready → {path}")

    if fmt in ("json", "all"):
        path = OUTPUT_DIR / f"leads_{timestamp}.json"
        with open(path, "w") as f:
            json.dump(all_rows, f, indent=2)
        files_written.append(str(path))
        logger.info(f"Wrote JSON → {path}")

    # Always write markdown summary
    md_path = _write_summary_report(all_rows, hot_rows, outreach_rows, timestamp)
    files_written.append(md_path)

    session.close()
    return {
        "files": files_written,
        "total": len(all_rows),
        "hot": len(hot_rows),
        "outreach_ready": len(outreach_rows),
    }


def _write_summary_report(
    all_rows: list[dict],
    hot_rows: list[dict],
    outreach_rows: list[dict],
    timestamp: str,
) -> str:
    """Write markdown summary report."""
    path = OUTPUT_DIR / f"summary_report_{timestamp}.md"

    tier_counts = {}
    for r in all_rows:
        t = r.get("lead_tier", "Unknown")
        tier_counts[t] = tier_counts.get(t, 0) + 1

    lines = [
        f"# MARKO Lead Report — {timestamp}",
        "",
        "## Summary",
        f"- **Total leads:** {len(all_rows)}",
        f"- **Hot:** {tier_counts.get('Hot', 0)}",
        f"- **Warm:** {tier_counts.get('Warm', 0)}",
        f"- **Mild:** {tier_counts.get('Mild', 0)}",
        f"- **Low:** {tier_counts.get('Low', 0)}",
        f"- **Outreach-ready:** {len(outreach_rows)}",
        "",
        "## Top 10 Opportunities",
        "",
        "| # | Business | City | Score | Tier | Top Reason |",
        "|---|----------|------|-------|------|------------|",
    ]

    for i, r in enumerate(all_rows[:10], 1):
        reason = (r.get("top_3_reasons") or "").split(" | ")[0]
        lines.append(
            f"| {i} | {r['business_name']} | {r['city']} "
            f"| {r['lead_score']} | {r['lead_tier']} | {reason} |"
        )

    lines += [
        "",
        "## Hot Leads with Contact Info",
        "",
    ]

    for r in hot_rows[:20]:
        lines.append(f"### {r['business_name']}")
        lines.append(f"- **Address:** {r['address']}")
        if r.get("phone"):
            lines.append(f"- **Phone:** {r['phone']}")
        if r.get("contact_email"):
            lines.append(f"- **Email:** {r['contact_email']}")
        if r.get("website_url"):
            lines.append(f"- **Website:** {r['website_url']}")
        lines.append(f"- **Score:** {r['lead_score']} ({r['lead_tier']})")
        lines.append(f"- **Reasons:** {r.get('top_3_reasons', '')}")
        lines.append("")

    lines += [
        "---",
        "_Generated by MARKO Lead Finder_",
        "_Use outreach_ready.csv for MARKO campaigns_",
    ]

    with open(path, "w") as f:
        f.write("\n".join(lines))

    logger.info(f"Summary report → {path}")
    return str(path)
