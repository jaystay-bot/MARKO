"""
services/search_service.py
Orchestrates place searches and persists results to the database.
"""
import json
import logging
from datetime import datetime
from sqlalchemy.orm import Session
from models import Lead, RunHistory
from schemas import PlaceResult
from utils import normalize_name, normalize_domain, normalize_phone
from database import get_session

logger = logging.getLogger("marko.search")


def _place_to_lead(place: PlaceResult, query: str) -> Lead:
    return Lead(
        source="google_places",
        source_place_id=place.place_id,
        business_name=place.business_name,
        normalized_name=normalize_name(place.business_name),
        primary_type=place.primary_type,
        address=place.address,
        city=place.city,
        state=place.state,
        postal_code=place.postal_code,
        country=place.country,
        lat=place.lat,
        lng=place.lng,
        phone=place.phone,
        website_url=place.website_url,
        normalized_domain=normalize_domain(place.website_url) if place.website_url else None,
        google_maps_url=place.google_maps_url,
        rating=place.rating,
        rating_count=place.rating_count,
        status=place.business_status or "active",
        query_used=query,
        discovered_at=datetime.utcnow(),
    )


def run_text_search(query: str, location: str, limit: int) -> dict:
    """Run text search and persist to DB. Returns summary dict."""
    from clients.google_places import text_search

    run = RunHistory(
        run_type="text_search",
        query=query,
        location=location,
        params_json=json.dumps({"query": query, "location": location, "limit": limit}),
        started_at=datetime.utcnow(),
    )

    session: Session = get_session()
    session.add(run)
    session.commit()

    logger.info(f"Starting text search: '{query}' in '{location}'")
    places = text_search(query, location, limit)
    inserted, skipped = 0, 0

    for place in places:
        existing = session.query(Lead).filter_by(
            source_place_id=place.place_id
        ).first()
        if existing:
            skipped += 1
            logger.debug(f"Skipped duplicate place_id: {place.place_id}")
            continue
        lead = _place_to_lead(place, f"{query} in {location}")
        session.add(lead)
        inserted += 1

    session.commit()

    run.finished_at = datetime.utcnow()
    run.total_found = len(places)
    session.commit()

    logger.info(
        f"Search complete — found={len(places)} inserted={inserted} skipped={skipped}"
    )
    session.close()
    return {"found": len(places), "inserted": inserted, "skipped": skipped}


def run_nearby_search(
    keyword: str, lat: float, lng: float,
    radius: int, limit: int
) -> dict:
    """Run nearby search and persist to DB. Returns summary dict."""
    from clients.google_places import nearby_search

    run = RunHistory(
        run_type="nearby_search",
        query=keyword,
        location=f"{lat},{lng}",
        params_json=json.dumps({
            "keyword": keyword, "lat": lat, "lng": lng,
            "radius": radius, "limit": limit
        }),
        started_at=datetime.utcnow(),
    )

    session: Session = get_session()
    session.add(run)
    session.commit()

    logger.info(f"Starting nearby search: '{keyword}' near ({lat},{lng})")
    places = nearby_search(keyword, lat, lng, radius, limit)
    inserted, skipped = 0, 0

    for place in places:
        existing = session.query(Lead).filter_by(
            source_place_id=place.place_id
        ).first()
        if existing:
            skipped += 1
            continue
        lead = _place_to_lead(place, f"{keyword} near {lat},{lng}")
        session.add(lead)
        inserted += 1

    session.commit()
    run.finished_at = datetime.utcnow()
    run.total_found = len(places)
    session.commit()

    logger.info(
        f"Nearby search complete — found={len(places)} "
        f"inserted={inserted} skipped={skipped}"
    )
    session.close()
    return {"found": len(places), "inserted": inserted, "skipped": skipped}
