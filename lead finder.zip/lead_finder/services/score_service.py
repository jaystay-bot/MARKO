"""
services/score_service.py
Scores each lead 0–100 based on digital weakness and outreach opportunity.
Higher score = more likely to need MARKO's help = better prospect.
"""
import json
import logging
from sqlalchemy.orm import Session
from models import Lead, OutreachSignal
from utils import tier_from_score
from database import get_session

logger = logging.getLogger("marko.score")

# Large chain / franchise keywords — lower priority
CHAIN_SIGNALS = [
    "nationwide", "franchise", "corporation", "inc.", "llc",
    "holdings", "group", "enterprises", "international",
    "corporate", "chain", "national"
]


def score_lead(lead: Lead, sig: OutreachSignal) -> tuple[int, list[str]]:
    """
    Score a single lead. Returns (score, reasons).
    Score represents outreach opportunity — higher = better prospect.
    """
    score = 0
    reasons: list[str] = []

    # ── OPPORTUNITY SIGNALS (add points) ──────────────────────

    if not sig or not sig.has_website:
        score += 20
        reasons.append("No website — strong opportunity")

    elif sig.dead_or_broken_site:
        score += 18
        reasons.append("Broken or parked website")

    elif sig.website_live is False:
        score += 16
        reasons.append("Website unreachable")

    else:
        if not sig.has_booking_page:
            score += 15
            reasons.append("No booking or quote flow")

        if not sig.has_contact_page:
            score += 12
            reasons.append("No contact page found")

        if not sig.has_cta:
            score += 10
            reasons.append("No clear CTA on homepage")

        if sig.missing_meta_description:
            score += 4
            reasons.append("Missing meta description")

        if sig.missing_title:
            score += 4
            reasons.append("Missing page title")

        if sig.social_only_presence:
            score += 8
            reasons.append("Facebook/social-only web presence")

        if sig.weak_mobile_clues:
            score += 3
            reasons.append("Possibly not mobile-optimized")

        if not sig.ssl_ok:
            score += 4
            reasons.append("No SSL / HTTP only")

    # Low review count
    if lead.rating_count is not None and lead.rating_count < 10:
        score += 6
        reasons.append("Very few reviews — low digital presence")
    elif lead.rating_count is not None and lead.rating_count < 30:
        score += 3
        reasons.append("Low review count")

    # No contact email found
    from models import Contact
    # We'll check via lead relationship
    contact = None
    if hasattr(lead, 'contacts') and lead.contacts:
        contact = lead.contacts[0]

    if not contact or not contact.email:
        score += 5
        reasons.append("No public email found")

    # ── NEGATIVE SIGNALS (subtract points) ────────────────────

    name_lower = (lead.business_name or "").lower()
    if any(kw in name_lower for kw in CHAIN_SIGNALS):
        score -= 15
        reasons.append("Likely large chain or franchise")

    if lead.is_duplicate:
        score -= 8
        reasons.append("Duplicate record")

    if lead.rating is not None and lead.rating >= 4.8 and (lead.rating_count or 0) > 500:
        score -= 10
        reasons.append("Highly rated established business")

    # Cap between 0 and 100
    score = max(0, min(100, score))

    return score, reasons


def run_scoring() -> dict:
    """Score all enriched, non-duplicate leads. Returns summary stats."""
    session: Session = get_session()

    leads = (
        session.query(Lead)
        .filter(
            Lead.enriched_at.isnot(None),
            Lead.is_duplicate == False,
        )
        .all()
    )

    logger.info(f"Scoring {len(leads)} leads...")
    scored = 0

    for lead in leads:
        sig = (
            session.query(OutreachSignal)
            .filter_by(lead_id=lead.id)
            .first()
        )

        s, reasons = score_lead(lead, sig)
        lead.lead_score = s
        lead.lead_tier = tier_from_score(s)
        lead.opportunity_flags_json = json.dumps(reasons)
        scored += 1

    session.commit()
    session.close()

    logger.info(f"Scoring complete — {scored} leads scored")
    return {"scored": scored}
