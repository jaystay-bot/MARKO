"""
services/enrich_service.py
Visits each lead's website, extracts contact info and site signals.
Compliant: real sites only, honest user-agent, no auth, no forms.
"""
import json
import logging
from datetime import datetime
from sqlalchemy.orm import Session
from models import Lead, Contact, OutreachSignal
from clients.website_fetcher import fetch_page, fetch_contact_page
from parsers.contact_parser import parse_contact_info, parse_site_signals
from utils import normalize_phone
from database import get_session

logger = logging.getLogger("marko.enrich")


def enrich_lead(lead: Lead, session: Session) -> bool:
    """
    Enrich a single lead from its website.
    Returns True on success, False on skip/error.
    """
    if not lead.website_url:
        # No website — still record the signal
        sig = session.query(OutreachSignal).filter_by(lead_id=lead.id).first()
        if not sig:
            sig = OutreachSignal(
                lead_id=lead.id,
                has_website=False,
                website_live=False,
                dead_or_broken_site=True,
            )
            session.add(sig)
        lead.enriched_at = datetime.utcnow()
        session.commit()
        return True

    logger.debug(f"Enriching: {lead.business_name} — {lead.website_url}")

    # Fetch homepage
    result = fetch_page(lead.website_url)

    if not result.is_live:
        logger.warning(
            f"Dead site for {lead.business_name}: {result.error}"
        )
        sig = session.query(OutreachSignal).filter_by(lead_id=lead.id).first()
        if not sig:
            sig = OutreachSignal(lead_id=lead.id)
            session.add(sig)
        sig.has_website = True
        sig.website_live = False
        sig.ssl_ok = result.ssl_ok
        sig.dead_or_broken_site = True
        sig.raw_signals_json = json.dumps({"error": result.error})
        lead.enriched_at = datetime.utcnow()
        session.commit()
        return False

    # Parse contact info from homepage
    contact_data = parse_contact_info(result.content or "", result.final_url or lead.website_url)

    # Parse site signals
    signals = parse_site_signals(result.content or "", result.final_url or lead.website_url)

    # Try to find contact/booking pages
    contact_url, booking_url = None, None
    if not contact_data.get("emails") or not signals.get("has_contact_page"):
        try:
            contact_url, booking_url = fetch_contact_page(
                result.final_url or lead.website_url
            )
            if contact_url:
                signals["has_contact_page"] = True
                # Re-parse contact page for emails
                cp_result = fetch_page(contact_url)
                if cp_result.is_live and cp_result.content:
                    cp_data = parse_contact_info(
                        cp_result.content, contact_url
                    )
                    # Merge — prefer contact page data
                    contact_data["emails"] = list(set(
                        contact_data.get("emails", []) + cp_data.get("emails", [])
                    ))
                    contact_data["phones"] = list(set(
                        contact_data.get("phones", []) + cp_data.get("phones", [])
                    ))
            if booking_url:
                signals["has_booking_page"] = True
        except Exception as e:
            logger.debug(f"Contact page probe failed: {e}")

    # Persist contact record
    existing_contact = session.query(Contact).filter_by(lead_id=lead.id).first()
    if not existing_contact:
        existing_contact = Contact(lead_id=lead.id)
        session.add(existing_contact)

    existing_contact.email = contact_data["emails"][0] if contact_data.get("emails") else None
    existing_contact.phone = contact_data["phones"][0] if contact_data.get("phones") else None
    existing_contact.contact_page_url = contact_url
    existing_contact.booking_page_url = booking_url
    existing_contact.facebook_url = contact_data.get("facebook_url")
    existing_contact.instagram_url = contact_data.get("instagram_url")
    existing_contact.linkedin_url = contact_data.get("linkedin_url")
    existing_contact.youtube_url = contact_data.get("youtube_url")
    existing_contact.source_url = result.final_url or lead.website_url

    # Persist signal record
    sig = session.query(OutreachSignal).filter_by(lead_id=lead.id).first()
    if not sig:
        sig = OutreachSignal(lead_id=lead.id)
        session.add(sig)

    sig.has_website = True
    sig.website_live = True
    sig.ssl_ok = result.ssl_ok
    sig.has_contact_page = signals.get("has_contact_page", False)
    sig.has_booking_page = signals.get("has_booking_page", False)
    sig.has_cta = signals.get("has_cta", False)
    sig.missing_meta_description = signals.get("missing_meta_description", False)
    sig.missing_title = signals.get("missing_title", False)
    sig.weak_mobile_clues = signals.get("weak_mobile_clues", False)
    sig.social_only_presence = signals.get("social_only_presence", False)
    sig.dead_or_broken_site = signals.get("dead_or_broken_site", False)
    sig.raw_signals_json = json.dumps({
        "response_time_ms": result.response_time_ms,
        "status_code": result.status_code,
        "final_url": result.final_url,
        "emails_found": contact_data.get("emails", []),
        "phones_found": contact_data.get("phones", []),
    })

    lead.enriched_at = datetime.utcnow()
    session.commit()

    logger.debug(
        f"Enriched: {lead.business_name} — "
        f"email={'yes' if existing_contact.email else 'no'} "
        f"live={result.is_live}"
    )
    return True


def run_enrichment(batch_size: int = 20) -> dict:
    """
    Enrich the next batch of unenriched leads.
    Returns summary stats.
    """
    session: Session = get_session()

    pending = (
        session.query(Lead)
        .filter(
            Lead.enriched_at.is_(None),
            Lead.is_duplicate == False,
        )
        .limit(batch_size)
        .all()
    )

    if not pending:
        logger.info("No leads pending enrichment.")
        session.close()
        return {"enriched": 0, "failed": 0, "skipped": 0}

    logger.info(f"Enriching {len(pending)} leads...")
    success, failed = 0, 0

    for lead in pending:
        try:
            ok = enrich_lead(lead, session)
            if ok:
                success += 1
            else:
                failed += 1
        except Exception as e:
            logger.error(f"Enrichment error for lead {lead.id}: {e}")
            lead.enriched_at = datetime.utcnow()
            lead.notes = f"Enrichment error: {str(e)[:200]}"
            session.commit()
            failed += 1

    logger.info(
        f"Enrichment batch complete — success={success} failed={failed}"
    )
    session.close()
    return {"enriched": success, "failed": failed, "skipped": 0}
