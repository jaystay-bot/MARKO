"""
config.py
All application settings loaded from environment variables via .env
"""
import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    GOOGLE_MAPS_API_KEY: str = os.getenv("GOOGLE_MAPS_API_KEY", "")
    DB_PATH: str = os.getenv("DB_PATH", "./marko_leads.db")
    HTTP_TIMEOUT: int = int(os.getenv("HTTP_TIMEOUT", "12"))
    MAX_RESULTS_PER_RUN: int = int(os.getenv("MAX_RESULTS_PER_RUN", "60"))
    ENRICHMENT_CONCURRENCY: int = int(os.getenv("ENRICHMENT_CONCURRENCY", "5"))
    USER_AGENT: str = os.getenv(
        "USER_AGENT",
        "MARKO-LeadFinder/1.0 (business-prospecting-tool)"
    )
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")

    # Google Places API (New) endpoints
    PLACES_TEXT_SEARCH_URL: str = (
        "https://places.googleapis.com/v1/places:searchText"
    )
    PLACES_NEARBY_SEARCH_URL: str = (
        "https://places.googleapis.com/v1/places:searchNearby"
    )

    # Fields to request from Places API (field mask)
    # Only request what we need to minimize billing
    PLACES_FIELD_MASK: str = ",".join([
        "places.id",
        "places.displayName",
        "places.formattedAddress",
        "places.primaryType",
        "places.types",
        "places.websiteUri",
        "places.nationalPhoneNumber",
        "places.internationalPhoneNumber",
        "places.googleMapsUri",
        "places.rating",
        "places.userRatingCount",
        "places.businessStatus",
        "places.location",
        "places.addressComponents",
    ])

    # Contact page paths to probe during enrichment
    CONTACT_PATHS: list[str] = [
        "/contact",
        "/contact-us",
        "/contacts",
        "/about",
        "/about-us",
        "/book",
        "/booking",
        "/appointment",
        "/appointments",
        "/schedule",
        "/request-quote",
        "/quote",
        "/estimate",
        "/get-started",
        "/free-quote",
    ]

    # Retry settings
    RETRY_MAX_ATTEMPTS: int = 3
    RETRY_WAIT_MIN: float = 1.0
    RETRY_WAIT_MAX: float = 8.0


config = Config()
