"""
utils.py
Shared utility functions: normalization, phone parsing, domain extraction.
"""
import re
import tldextract
from typing import Optional


def normalize_name(name: str) -> str:
    """Lowercase, strip punctuation, collapse whitespace."""
    if not name:
        return ""
    name = name.lower()
    name = re.sub(r"[^\w\s]", " ", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name


def normalize_domain(url: str) -> Optional[str]:
    """Extract registered domain from URL using tldextract."""
    if not url:
        return None
    try:
        extracted = tldextract.extract(url)
        if extracted.domain and extracted.suffix:
            return f"{extracted.domain}.{extracted.suffix}".lower()
    except Exception:
        pass
    return None


def normalize_phone(phone: str) -> Optional[str]:
    """Strip all non-digit characters for comparison."""
    if not phone:
        return None
    digits = re.sub(r"\D", "", phone)
    if len(digits) == 10:
        return f"1{digits}"
    if len(digits) == 11 and digits.startswith("1"):
        return digits
    return digits if digits else None


def normalize_address(address: str) -> str:
    """Lowercase and collapse whitespace for address comparison."""
    if not address:
        return ""
    address = address.lower()
    address = re.sub(r"\s+", " ", address).strip()
    return address


def clean_url(url: str) -> Optional[str]:
    """Ensure URL has a scheme."""
    if not url:
        return None
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url


def extract_emails_from_text(text: str) -> list[str]:
    """
    Extract publicly visible email addresses from text.
    Only extracts clearly formatted business emails.
    Does NOT guess or generate emails.
    """
    if not text:
        return []
    pattern = r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
    raw = re.findall(pattern, text)
    # Filter out obvious false positives
    filtered = []
    skip_patterns = [
        r"@example\.",
        r"@yourdomain\.",
        r"@domain\.",
        r"\.png$",
        r"\.jpg$",
        r"\.gif$",
        r"sentry\.",
        r"wixpress\.",
        r"squarespace\.",
    ]
    for email in raw:
        email_lower = email.lower()
        if any(re.search(p, email_lower) for p in skip_patterns):
            continue
        filtered.append(email.lower())
    return list(set(filtered))


def extract_phones_from_text(text: str) -> list[str]:
    """Extract phone numbers from text using common US formats."""
    if not text:
        return []
    pattern = r"(?:\+?1[\s\-.]?)?\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4}"
    found = re.findall(pattern, text)
    return [re.sub(r"\s+", " ", p).strip() for p in found]


def parse_city_state_from_address(address: str) -> tuple[str, str, str]:
    """
    Attempt to extract city, state, postal_code from a formatted address string.
    Returns (city, state, postal_code) or empty strings.
    """
    city, state, postal = "", "", ""
    if not address:
        return city, state, postal

    # Typical US format: "123 Main St, Richmond, VA 23220, USA"
    parts = [p.strip() for p in address.split(",")]
    if len(parts) >= 3:
        city = parts[-3] if len(parts) >= 3 else ""
        state_zip = parts[-2].strip() if len(parts) >= 2 else ""
        # State_zip might be "VA 23220"
        sz_parts = state_zip.split()
        if sz_parts:
            state = sz_parts[0]
        if len(sz_parts) > 1:
            postal = sz_parts[1]

    return city, state, postal


def tier_from_score(score: int) -> str:
    if score >= 80:
        return "Hot"
    elif score >= 60:
        return "Warm"
    elif score >= 40:
        return "Mild"
    return "Low"
