"""
database.py
Database initialization and session management.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from models import Base
from config import config
from logging_setup import logger


def init_db() -> sessionmaker:
    """Initialize database, create tables, return session factory."""
    engine = create_engine(
        f"sqlite:///{config.DB_PATH}",
        connect_args={"check_same_thread": False},
        echo=False,
    )
    Base.metadata.create_all(engine)
    logger.debug(f"Database ready at {config.DB_PATH}")
    return sessionmaker(bind=engine)


SessionLocal = init_db()


def get_session() -> Session:
    """Return a new database session."""
    return SessionLocal()
