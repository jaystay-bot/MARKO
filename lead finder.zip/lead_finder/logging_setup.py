"""
logging_setup.py
Structured logging configuration for MARKO lead finder.
"""
import logging
import sys
from config import config


def setup_logging() -> logging.Logger:
    level = getattr(logging, config.LOG_LEVEL.upper(), logging.INFO)

    fmt = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(fmt)

    root = logging.getLogger("marko")
    root.setLevel(level)
    root.addHandler(handler)
    root.propagate = False

    return root


logger = setup_logging()
