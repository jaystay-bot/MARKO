"""
models.py
SQLAlchemy ORM table definitions for MARKO lead database.
"""
from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Float, DateTime, Boolean,
    Text, ForeignKey, create_engine
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


class Lead(Base):
    __tablename__ = "leads"

    id = Column(Integer, primary_key=True, autoincrement=True)
    source = Column(String(50), default="google_places")
    source_place_id = Column(String(200), unique=True, nullable=True)
    business_name = Column(String(300), nullable=False)
    normalized_name = Column(String(300), nullable=True)
    primary_type = Column(String(200), nullable=True)
    address = Column(String(500), nullable=True)
    city = Column(String(100), nullable=True)
    state = Column(String(100), nullable=True)
    postal_code = Column(String(20), nullable=True)
    country = Column(String(100), nullable=True)
    lat = Column(Float, nullable=True)
    lng = Column(Float, nullable=True)
    phone = Column(String(50), nullable=True)
    website_url = Column(String(500), nullable=True)
    normalized_domain = Column(String(300), nullable=True)
    google_maps_url = Column(String(500), nullable=True)
    rating = Column(Float, nullable=True)
    rating_count = Column(Integer, nullable=True)
    status = Column(String(50), default="active")
    discovered_at = Column(DateTime, default=datetime.utcnow)
    enriched_at = Column(DateTime, nullable=True)
    lead_score = Column(Integer, nullable=True)
    lead_tier = Column(String(20), nullable=True)
    opportunity_flags_json = Column(Text, nullable=True)
    notes = Column(Text, nullable=True)
    is_duplicate = Column(Boolean, default=False)
    query_used = Column(String(300), nullable=True)

    contacts = relationship("Contact", back_populates="lead", cascade="all, delete-orphan")
    signals = relationship("OutreachSignal", back_populates="lead", cascade="all, delete-orphan", uselist=False)


class Contact(Base):
    __tablename__ = "contacts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=False)
    email = Column(String(300), nullable=True)
    phone = Column(String(50), nullable=True)
    contact_page_url = Column(String(500), nullable=True)
    booking_page_url = Column(String(500), nullable=True)
    facebook_url = Column(String(500), nullable=True)
    instagram_url = Column(String(500), nullable=True)
    linkedin_url = Column(String(500), nullable=True)
    youtube_url = Column(String(500), nullable=True)
    source_url = Column(String(500), nullable=True)
    confidence = Column(Float, default=1.0)

    lead = relationship("Lead", back_populates="contacts")


class OutreachSignal(Base):
    __tablename__ = "outreach_signals"

    id = Column(Integer, primary_key=True, autoincrement=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=False)
    has_website = Column(Boolean, default=False)
    website_live = Column(Boolean, nullable=True)
    ssl_ok = Column(Boolean, nullable=True)
    has_contact_page = Column(Boolean, nullable=True)
    has_booking_page = Column(Boolean, nullable=True)
    has_cta = Column(Boolean, nullable=True)
    missing_meta_description = Column(Boolean, nullable=True)
    missing_title = Column(Boolean, nullable=True)
    weak_mobile_clues = Column(Boolean, nullable=True)
    social_only_presence = Column(Boolean, nullable=True)
    dead_or_broken_site = Column(Boolean, nullable=True)
    raw_signals_json = Column(Text, nullable=True)

    lead = relationship("Lead", back_populates="signals")


class RunHistory(Base):
    __tablename__ = "run_history"

    id = Column(Integer, primary_key=True, autoincrement=True)
    run_type = Column(String(50), nullable=False)
    query = Column(String(300), nullable=True)
    location = Column(String(300), nullable=True)
    params_json = Column(Text, nullable=True)
    started_at = Column(DateTime, default=datetime.utcnow)
    finished_at = Column(DateTime, nullable=True)
    total_found = Column(Integer, default=0)
    total_enriched = Column(Integer, default=0)
    total_exported = Column(Integer, default=0)
    errors_json = Column(Text, nullable=True)
