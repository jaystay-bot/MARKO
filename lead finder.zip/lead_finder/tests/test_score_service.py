"""
tests/test_score_service.py
Unit tests for lead scoring logic.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.score_service import score_lead
from utils import tier_from_score


class MockLead:
    def __init__(self, **kwargs):
        self.id = kwargs.get("id", 1)
        self.business_name = kwargs.get("business_name", "Test Business")
        self.rating = kwargs.get("rating", None)
        self.rating_count = kwargs.get("rating_count", None)
        self.is_duplicate = kwargs.get("is_duplicate", False)
        self.contacts = kwargs.get("contacts", [])


class MockSignal:
    def __init__(self, **kwargs):
        self.has_website = kwargs.get("has_website", True)
        self.website_live = kwargs.get("website_live", True)
        self.ssl_ok = kwargs.get("ssl_ok", True)
        self.dead_or_broken_site = kwargs.get("dead_or_broken_site", False)
        self.has_booking_page = kwargs.get("has_booking_page", True)
        self.has_contact_page = kwargs.get("has_contact_page", True)
        self.has_cta = kwargs.get("has_cta", True)
        self.missing_meta_description = kwargs.get("missing_meta_description", False)
        self.missing_title = kwargs.get("missing_title", False)
        self.social_only_presence = kwargs.get("social_only_presence", False)
        self.weak_mobile_clues = kwargs.get("weak_mobile_clues", False)


def test_no_website_scores_high():
    lead = MockLead()
    sig = MockSignal(has_website=False)
    score, reasons = score_lead(lead, sig)
    assert score >= 20
    assert any("No website" in r for r in reasons)


def test_broken_site_scores_high():
    lead = MockLead()
    sig = MockSignal(dead_or_broken_site=True)
    score, reasons = score_lead(lead, sig)
    assert score >= 18
    assert any("Broken" in r or "broken" in r for r in reasons)


def test_missing_multiple_signals_accumulates():
    lead = MockLead()
    sig = MockSignal(
        has_booking_page=False,
        has_contact_page=False,
        has_cta=False,
        missing_meta_description=True,
        missing_title=True,
    )
    score, reasons = score_lead(lead, sig)
    assert score >= 45
    assert len(reasons) >= 3


def test_chain_business_scores_lower():
    lead = MockLead(business_name="National Plumbing Corporation Inc.")
    sig = MockSignal()
    score, reasons = score_lead(lead, sig)
    assert any("chain" in r.lower() or "franchise" in r.lower() for r in reasons)


def test_highly_rated_business_scores_lower():
    lead = MockLead(rating=4.9, rating_count=800)
    sig = MockSignal()
    score_before, _ = score_lead(MockLead(rating=None), sig)
    score_after, reasons = score_lead(lead, sig)
    assert any("established" in r.lower() for r in reasons)


def test_duplicate_penalized():
    lead = MockLead(is_duplicate=True)
    sig = MockSignal()
    score, reasons = score_lead(lead, sig)
    assert any("duplicate" in r.lower() for r in reasons)


def test_score_capped_at_100():
    lead = MockLead()
    sig = MockSignal(
        has_website=False,
        dead_or_broken_site=True,
        has_booking_page=False,
        has_contact_page=False,
        has_cta=False,
        missing_title=True,
        missing_meta_description=True,
        social_only_presence=True,
        ssl_ok=False,
    )
    score, _ = score_lead(lead, sig)
    assert score <= 100


def test_score_not_negative():
    lead = MockLead(
        business_name="Mega Corp International Holdings",
        rating=5.0,
        rating_count=2000,
        is_duplicate=True,
    )
    sig = MockSignal()
    score, _ = score_lead(lead, sig)
    assert score >= 0


def test_tier_hot():
    assert tier_from_score(85) == "Hot"
    assert tier_from_score(80) == "Hot"


def test_tier_warm():
    assert tier_from_score(70) == "Warm"
    assert tier_from_score(60) == "Warm"


def test_tier_mild():
    assert tier_from_score(50) == "Mild"
    assert tier_from_score(40) == "Mild"


def test_tier_low():
    assert tier_from_score(39) == "Low"
    assert tier_from_score(0) == "Low"


if __name__ == "__main__":
    tests = [
        test_no_website_scores_high,
        test_broken_site_scores_high,
        test_missing_multiple_signals_accumulates,
        test_chain_business_scores_lower,
        test_highly_rated_business_scores_lower,
        test_duplicate_penalized,
        test_score_capped_at_100,
        test_score_not_negative,
        test_tier_hot,
        test_tier_warm,
        test_tier_mild,
        test_tier_low,
    ]
    passed = 0
    for t in tests:
        try:
            t()
            print(f"  ✓ {t.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  ✗ {t.__name__}: {e}")
        except Exception as e:
            print(f"  ✗ {t.__name__} (error): {e}")
    print(f"\n{passed}/{len(tests)} tests passed")
