"""
tests/test_normalization.py
Unit tests for name, domain, phone, address normalization.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils import (
    normalize_name, normalize_domain, normalize_phone,
    normalize_address, extract_emails_from_text, extract_phones_from_text
)


def test_normalize_name_basic():
    # apostrophes become spaces, then collapsed
    assert normalize_name("Joe's Plumbing LLC") == "joe s plumbing llc"

def test_normalize_name_extra_spaces():
    # apostrophe → space, extra spaces collapsed
    assert normalize_name("  Bob's   Roofing  ") == "bob s roofing"

def test_normalize_name_empty():
    assert normalize_name("") == ""

def test_normalize_domain_standard():
    assert normalize_domain("https://www.richmondplumber.com/contact") == "richmondplumber.com"

def test_normalize_domain_subdomain():
    assert normalize_domain("http://bookings.mymedspa.com") == "mymedspa.com"

def test_normalize_domain_none():
    assert normalize_domain("") is None
    assert normalize_domain(None) is None

def test_normalize_phone_10digit():
    assert normalize_phone("804-555-1234") == "18045551234"

def test_normalize_phone_formatted():
    assert normalize_phone("(804) 555-1234") == "18045551234"

def test_normalize_phone_11digit():
    assert normalize_phone("+1 804 555 1234") == "18045551234"

def test_normalize_phone_none():
    assert normalize_phone("") is None
    assert normalize_phone(None) is None

def test_normalize_address():
    assert normalize_address("  123 Main St,  Richmond  VA  ") == "123 main st, richmond va"

def test_extract_emails_from_text():
    text = "Contact us at info@richmondplumbing.com or hello@example.com"
    emails = extract_emails_from_text(text)
    assert "info@richmondplumbing.com" in emails

def test_extract_emails_skips_fake():
    text = "Send to user@example.com or noreply@domain.com"
    emails = extract_emails_from_text(text)
    assert "user@example.com" not in emails

def test_extract_phones():
    text = "Call us: (804) 555-9876 or 804.555.4321"
    phones = extract_phones_from_text(text)
    assert len(phones) >= 1


if __name__ == "__main__":
    tests = [
        test_normalize_name_basic,
        test_normalize_name_extra_spaces,
        test_normalize_name_empty,
        test_normalize_domain_standard,
        test_normalize_domain_subdomain,
        test_normalize_domain_none,
        test_normalize_phone_10digit,
        test_normalize_phone_formatted,
        test_normalize_phone_11digit,
        test_normalize_phone_none,
        test_normalize_address,
        test_extract_emails_from_text,
        test_extract_emails_skips_fake,
        test_extract_phones,
    ]
    passed = 0
    for t in tests:
        try:
            t()
            print(f"  ✓ {t.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  ✗ {t.__name__}: {e}")
    print(f"\n{passed}/{len(tests)} tests passed")
