"""
tests/test_contact_parser.py
Unit tests for contact info and site signal extraction from HTML.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from parsers.contact_parser import parse_contact_info, parse_site_signals

SAMPLE_HTML_FULL = """
<!DOCTYPE html>
<html>
<head>
  <title>Richmond Plumbing Co</title>
  <meta name="description" content="Best plumbers in Richmond VA"/>
  <meta name="viewport" content="width=device-width"/>
</head>
<body>
  <h1>Richmond Plumbing</h1>
  <p>Call us: <a href="tel:+18045551234">(804) 555-1234</a></p>
  <p>Email: <a href="mailto:info@richmondplumbing.com">info@richmondplumbing.com</a></p>
  <a href="/contact">Contact Us</a>
  <a href="/book">Book Now</a>
  <a href="https://www.facebook.com/richmondplumbing">Facebook</a>
  <a href="https://www.instagram.com/richmondplumbing/">Instagram</a>
</body>
</html>
"""

SAMPLE_HTML_BARE = """
<!DOCTYPE html>
<html>
<body>
  <p>Welcome to our site.</p>
</body>
</html>
"""

SAMPLE_HTML_PARKED = """
<html>
<body>
  <p>This domain is for sale. Buy this domain.</p>
</body>
</html>
"""


def test_extract_email_from_mailto():
    result = parse_contact_info(SAMPLE_HTML_FULL, "http://test.com")
    assert "info@richmondplumbing.com" in result["emails"]


def test_extract_phone_from_tel():
    result = parse_contact_info(SAMPLE_HTML_FULL, "http://test.com")
    assert len(result["phones"]) >= 1


def test_extract_facebook():
    result = parse_contact_info(SAMPLE_HTML_FULL, "http://test.com")
    assert result.get("facebook_url") is not None
    assert "facebook.com" in result["facebook_url"]


def test_extract_instagram():
    result = parse_contact_info(SAMPLE_HTML_FULL, "http://test.com")
    assert result.get("instagram_url") is not None


def test_no_contact_info_on_bare_page():
    result = parse_contact_info(SAMPLE_HTML_BARE, "http://test.com")
    assert result["emails"] == []
    assert result["phones"] == []


def test_signals_full_site():
    signals = parse_site_signals(SAMPLE_HTML_FULL, "http://test.com")
    assert signals["missing_title"] == False
    assert signals["missing_meta_description"] == False
    assert signals["has_contact_page"] == True
    assert signals["has_booking_page"] == True
    assert signals["dead_or_broken_site"] == False


def test_signals_bare_site():
    signals = parse_site_signals(SAMPLE_HTML_BARE, "http://test.com")
    assert signals["missing_title"] == True
    assert signals["missing_meta_description"] == True
    assert signals["has_contact_page"] == False


def test_signals_parked_site():
    signals = parse_site_signals(SAMPLE_HTML_PARKED, "http://test.com")
    assert signals["dead_or_broken_site"] == True


def test_no_html_returns_empty():
    result = parse_contact_info("", "http://test.com")
    assert result["emails"] == []
    signals = parse_site_signals("", "http://test.com")
    assert signals["dead_or_broken_site"] == True


if __name__ == "__main__":
    tests = [
        test_extract_email_from_mailto,
        test_extract_phone_from_tel,
        test_extract_facebook,
        test_extract_instagram,
        test_no_contact_info_on_bare_page,
        test_signals_full_site,
        test_signals_bare_site,
        test_signals_parked_site,
        test_no_html_returns_empty,
    ]
    passed = 0
    for t in tests:
        try:
            t()
            print(f"  ✓ {t.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  ✗ {t.__name__}: {e}")
        except Exception as e:
            print(f"  ✗ {t.__name__} (error): {e}")
    print(f"\n{passed}/{len(tests)} tests passed")
