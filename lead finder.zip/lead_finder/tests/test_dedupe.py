"""
tests/test_dedupe.py
Unit tests for deduplication logic.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.dedupe_service import _is_duplicate


class MockLead:
    def __init__(self, **kwargs):
        self.source_place_id = kwargs.get("source_place_id")
        self.normalized_domain = kwargs.get("normalized_domain")
        self.normalized_name = kwargs.get("normalized_name")
        self.city = kwargs.get("city")
        self.phone = kwargs.get("phone")
        self.address = kwargs.get("address")
        self.website_url = kwargs.get("website_url")
        self.id = kwargs.get("id", 1)


def test_same_place_id():
    a = MockLead(source_place_id="ChIJ123")
    b = MockLead(source_place_id="ChIJ123")
    assert _is_duplicate(a, b)

def test_different_place_id():
    a = MockLead(source_place_id="ChIJ123")
    b = MockLead(source_place_id="ChIJ456")
    assert not _is_duplicate(a, b)

def test_same_domain():
    a = MockLead(normalized_domain="richmondplumbing.com")
    b = MockLead(normalized_domain="richmondplumbing.com")
    assert _is_duplicate(a, b)

def test_same_name_same_city():
    a = MockLead(normalized_name="richmond plumbing", city="Richmond")
    b = MockLead(normalized_name="richmond plumbing", city="Richmond")
    assert _is_duplicate(a, b)

def test_same_name_different_city():
    a = MockLead(normalized_name="richmond plumbing", city="Richmond")
    b = MockLead(normalized_name="richmond plumbing", city="Norfolk")
    assert not _is_duplicate(a, b)

def test_same_phone_same_city():
    a = MockLead(phone="8045551234", city="Richmond")
    b = MockLead(phone="(804) 555-1234", city="Richmond")
    assert _is_duplicate(a, b)

def test_no_data_no_match():
    a = MockLead()
    b = MockLead()
    assert not _is_duplicate(a, b)


if __name__ == "__main__":
    tests = [
        test_same_place_id,
        test_different_place_id,
        test_same_domain,
        test_same_name_same_city,
        test_same_name_different_city,
        test_same_phone_same_city,
        test_no_data_no_match,
    ]
    passed = 0
    for t in tests:
        try:
            t()
            print(f"  ✓ {t.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  ✗ {t.__name__}: {e}")
    print(f"\n{passed}/{len(tests)} tests passed")
