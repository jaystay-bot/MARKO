"""
clients/google_places.py
Official Google Places API (New) client.
Uses Text Search and Nearby Search endpoints only.
No scraping, no unofficial endpoints.
"""
import json
import logging
from typing import Optional
import requests
from tenacity import (
    retry, stop_after_attempt, wait_exponential,
    retry_if_exception_type, before_sleep_log
)
from config import config
from schemas import PlaceResult
from utils import normalize_domain, parse_city_state_from_address

logger = logging.getLogger("marko.places")


def _build_headers() -> dict:
    return {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": config.GOOGLE_MAPS_API_KEY,
        "X-Goog-FieldMask": config.PLACES_FIELD_MASK,
    }


def _parse_place(place: dict) -> Optional[PlaceResult]:
    """Parse a single place dict from API response into PlaceResult."""
    try:
        place_id = place.get("id", "")
        name = place.get("displayName", {}).get("text", "")
        if not place_id or not name:
            return None

        address = place.get("formattedAddress", "")
        city, state, postal = parse_city_state_from_address(address)

        location = place.get("location", {})
        lat = location.get("latitude")
        lng = location.get("longitude")

        # Address components for more accurate city/state
        components = place.get("addressComponents", [])
        for comp in components:
            types = comp.get("types", [])
            if "locality" in types:
                city = comp.get("longText", city)
            elif "administrative_area_level_1" in types:
                state = comp.get("shortText", state)
            elif "postal_code" in types:
                postal = comp.get("longText", postal)

        country = ""
        for comp in components:
            if "country" in comp.get("types", []):
                country = comp.get("shortText", "")

        website = place.get("websiteUri", "")
        domain = normalize_domain(website) if website else None

        return PlaceResult(
            place_id=place_id,
            business_name=name,
            address=address,
            city=city,
            state=state,
            postal_code=postal,
            country=country,
            lat=lat,
            lng=lng,
            phone=place.get("nationalPhoneNumber") or place.get("internationalPhoneNumber"),
            website_url=website or None,
            google_maps_url=place.get("googleMapsUri"),
            primary_type=place.get("primaryType"),
            rating=place.get("rating"),
            rating_count=place.get("userRatingCount"),
            business_status=place.get("businessStatus"),
        )
    except Exception as e:
        logger.warning(f"Failed to parse place: {e}")
        return None


@retry(
    stop=stop_after_attempt(config.RETRY_MAX_ATTEMPTS),
    wait=wait_exponential(
        min=config.RETRY_WAIT_MIN,
        max=config.RETRY_WAIT_MAX
    ),
    retry=retry_if_exception_type(requests.exceptions.RequestException),
    before_sleep=before_sleep_log(logger, logging.WARNING),
)
def _post(url: str, payload: dict) -> dict:
    resp = requests.post(
        url,
        headers=_build_headers(),
        json=payload,
        timeout=config.HTTP_TIMEOUT,
    )
    if resp.status_code == 429:
        raise requests.exceptions.RequestException("Rate limited (429)")
    if resp.status_code >= 500:
        raise requests.exceptions.RequestException(f"Server error {resp.status_code}")
    resp.raise_for_status()
    return resp.json()


def text_search(query: str, location: str, limit: int = 20) -> list[PlaceResult]:
    """
    Search businesses by text query + location string.
    Uses Places API (New) Text Search endpoint.
    """
    logger.info(f"Text search: '{query}' in '{location}' (limit={limit})")

    results: list[PlaceResult] = []
    page_token = None

    while len(results) < limit:
        payload: dict = {
            "textQuery": f"{query} in {location}",
            "pageSize": min(20, limit - len(results)),
            "languageCode": "en",
        }
        if page_token:
            payload["pageToken"] = page_token

        try:
            data = _post(config.PLACES_TEXT_SEARCH_URL, payload)
        except Exception as e:
            logger.error(f"Text search API error: {e}")
            break

        places = data.get("places", [])
        if not places:
            logger.info("No more results from API.")
            break

        for p in places:
            parsed = _parse_place(p)
            if parsed:
                results.append(parsed)

        page_token = data.get("nextPageToken")
        if not page_token:
            break

    logger.info(f"Text search returned {len(results)} places")
    return results[:limit]


def nearby_search(
    keyword: str,
    lat: float,
    lng: float,
    radius: int = 10000,
    limit: int = 20,
    included_types: Optional[list[str]] = None,
) -> list[PlaceResult]:
    """
    Search businesses near a lat/lng coordinate.
    Uses Places API (New) Nearby Search endpoint.
    """
    logger.info(
        f"Nearby search: '{keyword}' near ({lat},{lng}) "
        f"radius={radius}m limit={limit}"
    )

    results: list[PlaceResult] = []
    page_token = None

    while len(results) < limit:
        payload: dict = {
            "locationRestriction": {
                "circle": {
                    "center": {"latitude": lat, "longitude": lng},
                    "radius": float(radius),
                }
            },
            "maxResultCount": min(20, limit - len(results)),
            "languageCode": "en",
        }

        if keyword:
            payload["textQuery"] = keyword

        if included_types:
            payload["includedTypes"] = included_types

        if page_token:
            payload["pageToken"] = page_token

        try:
            data = _post(config.PLACES_NEARBY_SEARCH_URL, payload)
        except Exception as e:
            logger.error(f"Nearby search API error: {e}")
            break

        places = data.get("places", [])
        if not places:
            break

        for p in places:
            parsed = _parse_place(p)
            if parsed:
                results.append(parsed)

        page_token = data.get("nextPageToken")
        if not page_token:
            break

    logger.info(f"Nearby search returned {len(results)} places")
    return results[:limit]
