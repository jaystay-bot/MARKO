"""
clients/website_fetcher.py
Safe, compliant HTTP fetcher for visiting business websites.
Respects timeouts, uses honest user-agent, no evasion.
"""
import time
import logging
from typing import Optional
from dataclasses import dataclass
import requests
from requests.exceptions import (
    RequestException, SSLError, Timeout,
    TooManyRedirects, ConnectionError as ReqConnError
)
from tenacity import (
    retry, stop_after_attempt, wait_exponential,
    retry_if_exception_type, before_sleep_log
)
from config import config

logger = logging.getLogger("marko.fetcher")

MAX_CONTENT_BYTES = 500_000  # 500KB cap — enough for any contact page


@dataclass
class FetchResult:
    url: str
    final_url: Optional[str]
    status_code: Optional[int]
    content: Optional[str]
    response_time_ms: Optional[float]
    ssl_ok: bool
    is_live: bool
    error: Optional[str]


def _build_session() -> requests.Session:
    session = requests.Session()
    session.headers.update({
        "User-Agent": config.USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "keep-alive",
    })
    return session


_session = _build_session()


def fetch_page(url: str, ssl_verify: bool = True) -> FetchResult:
    """
    Fetch a single URL safely.
    Returns FetchResult with content or error.
    Does NOT bypass SSL. Does NOT follow unlimited redirects.
    """
    start = time.time()
    ssl_ok = ssl_verify

    try:
        resp = _session.get(
            url,
            timeout=config.HTTP_TIMEOUT,
            verify=ssl_verify,
            allow_redirects=True,
            stream=True,
        )
        elapsed = (time.time() - start) * 1000

        # Read up to cap
        content_bytes = b""
        for chunk in resp.iter_content(chunk_size=8192):
            content_bytes += chunk
            if len(content_bytes) >= MAX_CONTENT_BYTES:
                break

        # Detect encoding
        encoding = resp.encoding or "utf-8"
        try:
            content = content_bytes.decode(encoding, errors="replace")
        except Exception:
            content = content_bytes.decode("utf-8", errors="replace")

        return FetchResult(
            url=url,
            final_url=resp.url,
            status_code=resp.status_code,
            content=content if resp.ok else None,
            response_time_ms=elapsed,
            ssl_ok=ssl_ok,
            is_live=resp.ok,
            error=None if resp.ok else f"HTTP {resp.status_code}",
        )

    except SSLError:
        # Try without SSL verification as fallback (http-only site)
        if ssl_verify:
            logger.debug(f"SSL failed for {url}, retrying without verify")
            result = fetch_page(url, ssl_verify=False)
            result.ssl_ok = False
            return result
        return FetchResult(
            url=url, final_url=None, status_code=None, content=None,
            response_time_ms=None, ssl_ok=False, is_live=False,
            error="SSL error",
        )

    except Timeout:
        return FetchResult(
            url=url, final_url=None, status_code=None, content=None,
            response_time_ms=None, ssl_ok=False, is_live=False,
            error="Timeout",
        )

    except TooManyRedirects:
        return FetchResult(
            url=url, final_url=None, status_code=None, content=None,
            response_time_ms=None, ssl_ok=False, is_live=False,
            error="Too many redirects",
        )

    except ReqConnError as e:
        return FetchResult(
            url=url, final_url=None, status_code=None, content=None,
            response_time_ms=None, ssl_ok=False, is_live=False,
            error=f"Connection error: {str(e)[:80]}",
        )

    except RequestException as e:
        return FetchResult(
            url=url, final_url=None, status_code=None, content=None,
            response_time_ms=None, ssl_ok=False, is_live=False,
            error=str(e)[:120],
        )


def fetch_contact_page(base_url: str) -> tuple[Optional[str], Optional[str]]:
    """
    Try common contact and booking paths.
    Returns (contact_url, booking_url) — whichever were found.
    """
    from urllib.parse import urljoin

    contact_url = None
    booking_url = None

    booking_paths = {"/book", "/booking", "/appointment", "/appointments",
                     "/schedule", "/request-quote", "/quote", "/estimate",
                     "/get-started", "/free-quote"}
    contact_paths = {"/contact", "/contact-us", "/contacts", "/about", "/about-us"}

    all_paths = list(contact_paths) + list(booking_paths)

    for path in all_paths:
        url = urljoin(base_url, path)
        result = fetch_page(url)
        if result.is_live and result.status_code == 200:
            if path in contact_paths and not contact_url:
                contact_url = result.final_url or url
                logger.debug(f"Contact page found: {contact_url}")
            if path in booking_paths and not booking_url:
                booking_url = result.final_url or url
                logger.debug(f"Booking page found: {booking_url}")
        if contact_url and booking_url:
            break

    return contact_url, booking_url
