"""
schemas.py
Pydantic v2 schemas for validating and structuring data at each pipeline stage.
"""
from typing import Optional
from datetime import datetime
from pydantic import BaseModel, field_validator


class PlaceResult(BaseModel):
    """Raw place data from Google Places API."""
    place_id: str
    business_name: str
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    postal_code: Optional[str] = None
    country: Optional[str] = None
    lat: Optional[float] = None
    lng: Optional[float] = None
    phone: Optional[str] = None
    website_url: Optional[str] = None
    google_maps_url: Optional[str] = None
    primary_type: Optional[str] = None
    rating: Optional[float] = None
    rating_count: Optional[int] = None
    business_status: Optional[str] = None


class EnrichmentResult(BaseModel):
    """Data extracted from a business's own website."""
    lead_id: int
    homepage_url: str
    final_url: Optional[str] = None
    status_code: Optional[int] = None
    is_live: bool = False
    ssl_ok: bool = False
    response_time_ms: Optional[float] = None
    page_title: Optional[str] = None
    meta_description: Optional[str] = None
    emails: list[str] = []
    phones: list[str] = []
    contact_page_url: Optional[str] = None
    booking_page_url: Optional[str] = None
    facebook_url: Optional[str] = None
    instagram_url: Optional[str] = None
    linkedin_url: Optional[str] = None
    youtube_url: Optional[str] = None
    has_contact_page: bool = False
    has_booking_page: bool = False
    has_cta: bool = False
    missing_title: bool = False
    missing_meta_description: bool = False
    social_only_presence: bool = False
    dead_or_broken: bool = False
    error: Optional[str] = None


class ScoreResult(BaseModel):
    """Lead scoring output."""
    lead_id: int
    score: int
    tier: str
    reasons: list[str]


class LeadExportRow(BaseModel):
    """Flattened row for CSV/JSON export."""
    business_name: str
    category: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    phone: Optional[str] = None
    website_url: Optional[str] = None
    contact_email: Optional[str] = None
    contact_page_url: Optional[str] = None
    booking_page_url: Optional[str] = None
    lead_score: Optional[int] = None
    lead_tier: Optional[str] = None
    top_3_reasons: Optional[str] = None
    google_maps_url: Optional[str] = None
    source: Optional[str] = None
    notes: Optional[str] = None
