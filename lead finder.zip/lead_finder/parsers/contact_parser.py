"""
parsers/contact_parser.py
Parses business websites for publicly visible contact information.
Only extracts what is clearly displayed on the page.
No guessing, no form submission, no auth.
"""
import re
import logging
from typing import Optional
from bs4 import BeautifulSoup
from utils import extract_emails_from_text, extract_phones_from_text

logger = logging.getLogger("marko.contact_parser")

SOCIAL_PATTERNS = {
    "facebook": r"facebook\.com/(?!sharer|share|dialog|plugins)[^\s\"'?#]+",
    "instagram": r"instagram\.com/[^\s\"'?#]+",
    "linkedin": r"linkedin\.com/(?:company|in)/[^\s\"'?#]+",
    "youtube": r"youtube\.com/(?:c/|channel/|user/|@)[^\s\"'?#]+",
}


def parse_contact_info(html: str, page_url: str) -> dict:
    """
    Extract all publicly visible contact info from HTML.
    Returns dict with emails, phones, social links.
    """
    if not html:
        return _empty_result()

    soup = BeautifulSoup(html, "lxml")

    # Remove script/style to avoid false positives
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()

    text = soup.get_text(separator=" ", strip=True)

    emails = _extract_emails(soup, text)
    phones = _extract_phones(soup, text)
    socials = _extract_social_links(soup, html)

    return {
        "emails": emails,
        "phones": phones,
        **socials,
    }


def _empty_result() -> dict:
    return {
        "emails": [],
        "phones": [],
        "facebook_url": None,
        "instagram_url": None,
        "linkedin_url": None,
        "youtube_url": None,
    }


def _extract_emails(soup: BeautifulSoup, text: str) -> list[str]:
    emails = set()

    # From mailto: links — most reliable
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href.startswith("mailto:"):
            email = href.replace("mailto:", "").split("?")[0].strip().lower()
            if email and "@" in email:
                emails.add(email)

    # From visible text
    for e in extract_emails_from_text(text):
        emails.add(e)

    return list(emails)


def _extract_phones(soup: BeautifulSoup, text: str) -> list[str]:
    phones = set()

    # From tel: links — most reliable
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href.startswith("tel:"):
            phone = href.replace("tel:", "").strip()
            if phone:
                phones.add(phone)

    # From visible text
    for p in extract_phones_from_text(text):
        phones.add(p)

    return list(phones)[:5]  # cap at 5


def _extract_social_links(soup: BeautifulSoup, raw_html: str) -> dict:
    """Extract social media links from anchor tags."""
    result = {
        "facebook_url": None,
        "instagram_url": None,
        "linkedin_url": None,
        "youtube_url": None,
    }

    for a in soup.find_all("a", href=True):
        href = a["href"].lower().strip()
        if not href:
            continue

        for platform, pattern in SOCIAL_PATTERNS.items():
            key = f"{platform}_url"
            if result[key]:
                continue
            if platform in href:
                match = re.search(pattern, href)
                if match:
                    result[key] = "https://" + match.group(0).lstrip("/")

    return result


def parse_site_signals(
    html: str,
    page_url: str,
    soup: Optional[BeautifulSoup] = None
) -> dict:
    """
    Detect site quality signals from homepage HTML.
    Returns dict of boolean flags.
    """
    if not html:
        return _empty_signals()

    if soup is None:
        soup = BeautifulSoup(html, "lxml")

    title_tag = soup.find("title")
    meta_desc = soup.find("meta", attrs={"name": "description"})
    missing_title = not title_tag or not title_tag.get_text(strip=True)
    missing_meta = not meta_desc or not meta_desc.get("content", "").strip()

    # Check for any CTA button/link
    cta_keywords = [
        "book", "schedule", "appointment", "get a quote", "free quote",
        "contact us", "call us", "get started", "request", "estimate",
        "buy now", "shop now", "order now", "sign up", "try free"
    ]
    text_lower = soup.get_text(separator=" ").lower()
    has_cta = any(kw in text_lower for kw in cta_keywords)

    # Detect contact page link
    has_contact_link = False
    has_booking_link = False
    for a in soup.find_all("a", href=True):
        href = a["href"].lower()
        if any(p in href for p in ["/contact", "/about", "/reach"]):
            has_contact_link = True
        if any(p in href for p in ["/book", "/appointment", "/schedule", "/quote"]):
            has_booking_link = True

    # Social-only detection
    has_facebook = "facebook.com" in html.lower()
    has_instagram = "instagram.com" in html.lower()
    has_youtube = "youtube.com" in html.lower()
    has_linkedin = "linkedin.com" in html.lower()
    social_only = (
        (has_facebook or has_instagram)
        and not has_contact_link
        and missing_title
    )

    # Parked / placeholder detection
    parked_signals = [
        "this domain is for sale",
        "domain parked",
        "coming soon",
        "under construction",
        "website coming soon",
        "buy this domain",
        "godaddy",
        "namecheap parking",
        "this site is under",
        "placeholder page",
    ]
    dead_or_broken = any(s in text_lower for s in parked_signals)

    # Mobile viewport
    viewport = soup.find("meta", attrs={"name": "viewport"})
    weak_mobile = not bool(viewport)

    return {
        "has_contact_page": has_contact_link,
        "has_booking_page": has_booking_link,
        "has_cta": has_cta,
        "missing_title": missing_title,
        "missing_meta_description": missing_meta,
        "social_only_presence": social_only,
        "dead_or_broken_site": dead_or_broken,
        "weak_mobile_clues": weak_mobile,
    }


def _empty_signals() -> dict:
    return {
        "has_contact_page": False,
        "has_booking_page": False,
        "has_cta": False,
        "missing_title": True,
        "missing_meta_description": True,
        "social_only_presence": False,
        "dead_or_broken_site": True,
        "weak_mobile_clues": True,
    }
